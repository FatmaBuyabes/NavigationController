//
//  ViewController.swift
//  NavigationController
//
//  Created by Fatma Buyabes on 29/02/2024.
//

import UIKit
import SnapKit
class ViewController: UIViewController {

    let detailsButton = UIButton(type: .infoLight)
    
    override func viewDidLoad() {
        title = "First View Controller"
        view.backgroundColor = .lightGray
        // Do any additional setup after loading the view.
        
        view.addSubview(detailsButton)
        setUpUi()
        setUpNavigationBar()
        setupAutoLayout()
        detailsButton.addTarget(self, action: #selector(showDetailsTapped), for: .touchUpInside)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func setupAutoLayout(){
        detailsButton.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
    }
    func setUpUi(){
        detailsButton.setTitle("Show Details", for: .normal)
        detailsButton.backgroundColor = .white
        detailsButton.layer.cornerRadius = 15
    }
    func setUpNavigationBar(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }
    @objc func showDetailsTapped(){
        let secondVC = SecondViewController()
        secondVC.recivedData = "Welcome to Details View !🙋🏻‍♀️ "
        
        self.navigationController?.pushViewController(secondVC, animated: true)
        
    }
    
}

