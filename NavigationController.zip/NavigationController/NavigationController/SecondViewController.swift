//
//  SecondViewController.swift
//  NavigationController
//
//  Created by Fatma Buyabes on 29/02/2024.
//

import UIKit
import SnapKit

class SecondViewController: UIViewController {
    
    let recivedMessage = UILabel()
    let genreContainerView = UIView()
    let genreLabel = UILabel()
    let genreLabel2 = UILabel()
    let genreLabel3 = UILabel()
    var recivedData: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        genreContainerView.addSubview(genreLabel)
        view.addSubview(genreContainerView)
        view.backgroundColor = .white
        view.addSubview(recivedMessage)
        setUpUi()
        setupAutoLayout()
        recivedMessage.text = recivedData
        
        // Do any additional setup after loading the view.
    }
    
    func setupAutoLayout(){
        recivedMessage.snp.makeConstraints { make in
            make.center.equalToSuperview()
            
        }
    }
    func setUpUi(){
        recivedMessage.textColor = .darkGray
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
